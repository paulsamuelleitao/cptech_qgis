from qgis.core import (
    QgsProject, QgsVectorLayer, QgsField,
    QgsPalLayerSettings, QgsTextFormat,
    QgsTextBufferSettings, QgsVectorLayerSimpleLabeling,
    edit
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor


def getATS(feature, reference_tag, paramtype, padding):
    attribute_name = str(reference_tag)+paramtype
    #Truncate attribute name
    attribute_name = attribute_name[:10]
    out = feature[attribute_name]
    #Pad to 2 wide with zeros
    out = f"{out:0>{padding}}"
    return out


# Loop through each feature in the layer
def getStandardLSD(feature):
    # 2. Access a specific attribute by field name
    reference_endpoint = feature['layer']
    match reference_endpoint:
        case 'verticesTO':
            reference_tag = 'To'
        case 'verticesFROM':
            reference_tag = 'From'
    
    LSD = getATS(feature, reference_tag, "LSD", 2)
    SEC = getATS(feature, reference_tag, "Section", 2)
    TWN = getATS(feature, reference_tag, "Township", 3)
    RNG = getATS(feature, reference_tag, "Range", 2)
    MER = getATS(feature, reference_tag, "Meridian", 1)
    
    standardLSD = LSD+"-"+SEC+"-"+TWN+"-"+RNG+"W"+MER
    return standardLSD
        
# Get the active layer
layer = QgsProject.instance().mapLayersByName('SurveyPoints')[0]

#Create StandardLSD Field in data
provider = layer.dataProvider()
add_field_name = "StandardLSD"
if layer.fields().indexOf(add_field_name) == -1:
    provider.addAttributes([QgsField(add_field_name, QVariant.String)])

#Compute and write StandardLSD field
with edit(layer):
    for feature in layer.getFeatures():
        lsd = getStandardLSD(feature)
        feature['StandardLSD'] = lsd
        layer.updateFeature(feature) 
        print(lsd)
    
# 2. Instantiate and configure the labeling settings
settings = QgsPalLayerSettings()
settings.fieldName = "StandardLSD"
settings.isExpression = False

text_format = QgsTextFormat()
text_format.setSize(14.0)
text_format.setColor(QColor("white"))

# Configure buffer first
buffer_settings = QgsTextBufferSettings()
buffer_settings.setEnabled(True)
buffer_settings.setSize(1)
buffer_settings.setColor(QColor("black"))
text_format.setBuffer(buffer_settings)  # Attach buffer to format

settings.setFormat(text_format)

labeling = QgsVectorLayerSimpleLabeling(settings)
layer.setLabeling(labeling)
layer.setLabelsEnabled(True)
layer.triggerRepaint()