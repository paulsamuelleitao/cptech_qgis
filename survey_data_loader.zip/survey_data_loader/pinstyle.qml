<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis readOnly="0" autoRefreshTime="0" simplifyDrawingHints="0" labelsEnabled="0" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" simplifyAlgorithm="0" simplifyDrawingTol="1" styleCategories="AllStyleCategories" minScale="100000000" simplifyLocal="1" maxScale="0" version="3.40.14-Bratislava" autoRefreshMode="Disabled" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startField="Date" enabled="0" durationUnit="min" accumulate="0" mode="0" endField="" endExpression="" startExpression="" fixedDuration="0" durationField="LSD" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation type="IndividualFeatures" showMarkerSymbolInSurfacePlots="0" symbology="Line" zoffset="0" clamping="Terrain" respectLayerSymbol="1" zscale="1" extrusionEnabled="0" binding="Centroid" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" clip_to_extent="1" name="" force_rhr="0" alpha="1" frame_rate="10" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="0" locked="0" id="{7842c71c-dd59-4d29-a6c0-912e177d9ffd}">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" clip_to_extent="1" name="" force_rhr="0" alpha="1" frame_rate="10" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleFill" pass="0" locked="0" id="{2e7bebdc-9826-4c40-a345-583c8f0d065a}">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255,rgb:0.51259632257572285,0.20167849240863661,0.21007095445181964,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" clip_to_extent="1" name="" force_rhr="0" alpha="1" frame_rate="10" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleMarker" pass="0" locked="0" id="{42f4ffd0-d6c4-433a-a40b-5fbe6169741a}">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="131,51,54,255,rgb:0.51259632257572285,0.20167849240863661,0.21007095445181964,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol type="marker" clip_to_extent="1" name="0" force_rhr="0" alpha="1" frame_rate="10" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SvgMarker" pass="0" locked="0" id="{8880fe46-92fa-43fd-a944-4741eb807017}">
          <Option type="Map">
            <Option type="QString" name="angle" value="180"/>
            <Option type="QString" name="color" value="35,255,35,255,rgb:0.13725490196078433,1,0.13725490196078433,1"/>
            <Option type="QString" name="fixedAspectRatio" value="0"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="name" value="arrows/NorthArrow_11.svg"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option name="parameters"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="6"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol type="marker" clip_to_extent="1" name="" force_rhr="0" alpha="1" frame_rate="10" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleMarker" pass="0" locked="0" id="{53a1c687-2d1a-485d-96ad-14763733657d}">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="circle"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="2"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option type="int" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="Technician Name" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Date" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LSD" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SEC" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TWN" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="RNG" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MER" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Location" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Location Description" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Secondary Description" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Structure Description" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="License #" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Line #" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="AER License #" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Latitude" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Longitude" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Pipe Size" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Material" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Substance" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Operational Status" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="AC Potential (VAC)" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Static (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Structure Potential ON (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Structure Potential OFF (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Other Potential ON (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Other Potential OFF (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Swain Current Return(+)/Drain(-) (mA)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Swain Current Return(+)/Drain(-) (mA) OFF" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Bond Current Return(+)/Drain(-) (mA)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Bond Current Return(+)/Drain(-) (mA) OFF" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Isolation Kit (%)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Anode Potential (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Anode Current (mA)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="As Found Structure ON (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="As Found Structure OFF (-mVCSE)" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Access" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Deficiency ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Reading Comments" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="Technician Name" name="" index="0"/>
    <alias field="Date" name="" index="1"/>
    <alias field="LSD" name="" index="2"/>
    <alias field="SEC" name="" index="3"/>
    <alias field="TWN" name="" index="4"/>
    <alias field="RNG" name="" index="5"/>
    <alias field="MER" name="" index="6"/>
    <alias field="Location" name="" index="7"/>
    <alias field="Location Description" name="" index="8"/>
    <alias field="Secondary Description" name="" index="9"/>
    <alias field="Structure Description" name="" index="10"/>
    <alias field="License #" name="" index="11"/>
    <alias field="Line #" name="" index="12"/>
    <alias field="AER License #" name="" index="13"/>
    <alias field="Latitude" name="" index="14"/>
    <alias field="Longitude" name="" index="15"/>
    <alias field="Pipe Size" name="" index="16"/>
    <alias field="Material" name="" index="17"/>
    <alias field="Substance" name="" index="18"/>
    <alias field="Operational Status" name="" index="19"/>
    <alias field="AC Potential (VAC)" name="" index="20"/>
    <alias field="Static (-mVCSE)" name="" index="21"/>
    <alias field="Structure Potential ON (-mVCSE)" name="" index="22"/>
    <alias field="Structure Potential OFF (-mVCSE)" name="" index="23"/>
    <alias field="Other Potential ON (-mVCSE)" name="" index="24"/>
    <alias field="Other Potential OFF (-mVCSE)" name="" index="25"/>
    <alias field="Swain Current Return(+)/Drain(-) (mA)" name="" index="26"/>
    <alias field="Swain Current Return(+)/Drain(-) (mA) OFF" name="" index="27"/>
    <alias field="Bond Current Return(+)/Drain(-) (mA)" name="" index="28"/>
    <alias field="Bond Current Return(+)/Drain(-) (mA) OFF" name="" index="29"/>
    <alias field="Isolation Kit (%)" name="" index="30"/>
    <alias field="Anode Potential (-mVCSE)" name="" index="31"/>
    <alias field="Anode Current (mA)" name="" index="32"/>
    <alias field="As Found Structure ON (-mVCSE)" name="" index="33"/>
    <alias field="As Found Structure OFF (-mVCSE)" name="" index="34"/>
    <alias field="Access" name="" index="35"/>
    <alias field="Deficiency ID" name="" index="36"/>
    <alias field="Reading Comments" name="" index="37"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="Technician Name"/>
    <policy policy="Duplicate" field="Date"/>
    <policy policy="Duplicate" field="LSD"/>
    <policy policy="Duplicate" field="SEC"/>
    <policy policy="Duplicate" field="TWN"/>
    <policy policy="Duplicate" field="RNG"/>
    <policy policy="Duplicate" field="MER"/>
    <policy policy="Duplicate" field="Location"/>
    <policy policy="Duplicate" field="Location Description"/>
    <policy policy="Duplicate" field="Secondary Description"/>
    <policy policy="Duplicate" field="Structure Description"/>
    <policy policy="Duplicate" field="License #"/>
    <policy policy="Duplicate" field="Line #"/>
    <policy policy="Duplicate" field="AER License #"/>
    <policy policy="Duplicate" field="Latitude"/>
    <policy policy="Duplicate" field="Longitude"/>
    <policy policy="Duplicate" field="Pipe Size"/>
    <policy policy="Duplicate" field="Material"/>
    <policy policy="Duplicate" field="Substance"/>
    <policy policy="Duplicate" field="Operational Status"/>
    <policy policy="Duplicate" field="AC Potential (VAC)"/>
    <policy policy="Duplicate" field="Static (-mVCSE)"/>
    <policy policy="Duplicate" field="Structure Potential ON (-mVCSE)"/>
    <policy policy="Duplicate" field="Structure Potential OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Other Potential ON (-mVCSE)"/>
    <policy policy="Duplicate" field="Other Potential OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Swain Current Return(+)/Drain(-) (mA)"/>
    <policy policy="Duplicate" field="Swain Current Return(+)/Drain(-) (mA) OFF"/>
    <policy policy="Duplicate" field="Bond Current Return(+)/Drain(-) (mA)"/>
    <policy policy="Duplicate" field="Bond Current Return(+)/Drain(-) (mA) OFF"/>
    <policy policy="Duplicate" field="Isolation Kit (%)"/>
    <policy policy="Duplicate" field="Anode Potential (-mVCSE)"/>
    <policy policy="Duplicate" field="Anode Current (mA)"/>
    <policy policy="Duplicate" field="As Found Structure ON (-mVCSE)"/>
    <policy policy="Duplicate" field="As Found Structure OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Access"/>
    <policy policy="Duplicate" field="Deficiency ID"/>
    <policy policy="Duplicate" field="Reading Comments"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="Technician Name"/>
    <policy policy="Duplicate" field="Date"/>
    <policy policy="Duplicate" field="LSD"/>
    <policy policy="Duplicate" field="SEC"/>
    <policy policy="Duplicate" field="TWN"/>
    <policy policy="Duplicate" field="RNG"/>
    <policy policy="Duplicate" field="MER"/>
    <policy policy="Duplicate" field="Location"/>
    <policy policy="Duplicate" field="Location Description"/>
    <policy policy="Duplicate" field="Secondary Description"/>
    <policy policy="Duplicate" field="Structure Description"/>
    <policy policy="Duplicate" field="License #"/>
    <policy policy="Duplicate" field="Line #"/>
    <policy policy="Duplicate" field="AER License #"/>
    <policy policy="Duplicate" field="Latitude"/>
    <policy policy="Duplicate" field="Longitude"/>
    <policy policy="Duplicate" field="Pipe Size"/>
    <policy policy="Duplicate" field="Material"/>
    <policy policy="Duplicate" field="Substance"/>
    <policy policy="Duplicate" field="Operational Status"/>
    <policy policy="Duplicate" field="AC Potential (VAC)"/>
    <policy policy="Duplicate" field="Static (-mVCSE)"/>
    <policy policy="Duplicate" field="Structure Potential ON (-mVCSE)"/>
    <policy policy="Duplicate" field="Structure Potential OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Other Potential ON (-mVCSE)"/>
    <policy policy="Duplicate" field="Other Potential OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Swain Current Return(+)/Drain(-) (mA)"/>
    <policy policy="Duplicate" field="Swain Current Return(+)/Drain(-) (mA) OFF"/>
    <policy policy="Duplicate" field="Bond Current Return(+)/Drain(-) (mA)"/>
    <policy policy="Duplicate" field="Bond Current Return(+)/Drain(-) (mA) OFF"/>
    <policy policy="Duplicate" field="Isolation Kit (%)"/>
    <policy policy="Duplicate" field="Anode Potential (-mVCSE)"/>
    <policy policy="Duplicate" field="Anode Current (mA)"/>
    <policy policy="Duplicate" field="As Found Structure ON (-mVCSE)"/>
    <policy policy="Duplicate" field="As Found Structure OFF (-mVCSE)"/>
    <policy policy="Duplicate" field="Access"/>
    <policy policy="Duplicate" field="Deficiency ID"/>
    <policy policy="Duplicate" field="Reading Comments"/>
  </duplicatePolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="Technician Name"/>
    <default expression="" applyOnUpdate="0" field="Date"/>
    <default expression="" applyOnUpdate="0" field="LSD"/>
    <default expression="" applyOnUpdate="0" field="SEC"/>
    <default expression="" applyOnUpdate="0" field="TWN"/>
    <default expression="" applyOnUpdate="0" field="RNG"/>
    <default expression="" applyOnUpdate="0" field="MER"/>
    <default expression="" applyOnUpdate="0" field="Location"/>
    <default expression="" applyOnUpdate="0" field="Location Description"/>
    <default expression="" applyOnUpdate="0" field="Secondary Description"/>
    <default expression="" applyOnUpdate="0" field="Structure Description"/>
    <default expression="" applyOnUpdate="0" field="License #"/>
    <default expression="" applyOnUpdate="0" field="Line #"/>
    <default expression="" applyOnUpdate="0" field="AER License #"/>
    <default expression="" applyOnUpdate="0" field="Latitude"/>
    <default expression="" applyOnUpdate="0" field="Longitude"/>
    <default expression="" applyOnUpdate="0" field="Pipe Size"/>
    <default expression="" applyOnUpdate="0" field="Material"/>
    <default expression="" applyOnUpdate="0" field="Substance"/>
    <default expression="" applyOnUpdate="0" field="Operational Status"/>
    <default expression="" applyOnUpdate="0" field="AC Potential (VAC)"/>
    <default expression="" applyOnUpdate="0" field="Static (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Structure Potential ON (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Structure Potential OFF (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Other Potential ON (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Other Potential OFF (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Swain Current Return(+)/Drain(-) (mA)"/>
    <default expression="" applyOnUpdate="0" field="Swain Current Return(+)/Drain(-) (mA) OFF"/>
    <default expression="" applyOnUpdate="0" field="Bond Current Return(+)/Drain(-) (mA)"/>
    <default expression="" applyOnUpdate="0" field="Bond Current Return(+)/Drain(-) (mA) OFF"/>
    <default expression="" applyOnUpdate="0" field="Isolation Kit (%)"/>
    <default expression="" applyOnUpdate="0" field="Anode Potential (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Anode Current (mA)"/>
    <default expression="" applyOnUpdate="0" field="As Found Structure ON (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="As Found Structure OFF (-mVCSE)"/>
    <default expression="" applyOnUpdate="0" field="Access"/>
    <default expression="" applyOnUpdate="0" field="Deficiency ID"/>
    <default expression="" applyOnUpdate="0" field="Reading Comments"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" field="Technician Name" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Date" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="LSD" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="SEC" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="TWN" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="RNG" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="MER" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Location" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Location Description" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Secondary Description" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Structure Description" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="License #" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Line #" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="AER License #" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Latitude" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Longitude" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Pipe Size" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Material" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Substance" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Operational Status" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="AC Potential (VAC)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Static (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Structure Potential ON (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Structure Potential OFF (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Other Potential ON (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Other Potential OFF (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Swain Current Return(+)/Drain(-) (mA)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Swain Current Return(+)/Drain(-) (mA) OFF" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Bond Current Return(+)/Drain(-) (mA)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Bond Current Return(+)/Drain(-) (mA) OFF" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Isolation Kit (%)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Anode Potential (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Anode Current (mA)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="As Found Structure ON (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="As Found Structure OFF (-mVCSE)" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Access" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Deficiency ID" exp_strength="0" constraints="0" notnull_strength="0"/>
    <constraint unique_strength="0" field="Reading Comments" exp_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="Technician Name" desc=""/>
    <constraint exp="" field="Date" desc=""/>
    <constraint exp="" field="LSD" desc=""/>
    <constraint exp="" field="SEC" desc=""/>
    <constraint exp="" field="TWN" desc=""/>
    <constraint exp="" field="RNG" desc=""/>
    <constraint exp="" field="MER" desc=""/>
    <constraint exp="" field="Location" desc=""/>
    <constraint exp="" field="Location Description" desc=""/>
    <constraint exp="" field="Secondary Description" desc=""/>
    <constraint exp="" field="Structure Description" desc=""/>
    <constraint exp="" field="License #" desc=""/>
    <constraint exp="" field="Line #" desc=""/>
    <constraint exp="" field="AER License #" desc=""/>
    <constraint exp="" field="Latitude" desc=""/>
    <constraint exp="" field="Longitude" desc=""/>
    <constraint exp="" field="Pipe Size" desc=""/>
    <constraint exp="" field="Material" desc=""/>
    <constraint exp="" field="Substance" desc=""/>
    <constraint exp="" field="Operational Status" desc=""/>
    <constraint exp="" field="AC Potential (VAC)" desc=""/>
    <constraint exp="" field="Static (-mVCSE)" desc=""/>
    <constraint exp="" field="Structure Potential ON (-mVCSE)" desc=""/>
    <constraint exp="" field="Structure Potential OFF (-mVCSE)" desc=""/>
    <constraint exp="" field="Other Potential ON (-mVCSE)" desc=""/>
    <constraint exp="" field="Other Potential OFF (-mVCSE)" desc=""/>
    <constraint exp="" field="Swain Current Return(+)/Drain(-) (mA)" desc=""/>
    <constraint exp="" field="Swain Current Return(+)/Drain(-) (mA) OFF" desc=""/>
    <constraint exp="" field="Bond Current Return(+)/Drain(-) (mA)" desc=""/>
    <constraint exp="" field="Bond Current Return(+)/Drain(-) (mA) OFF" desc=""/>
    <constraint exp="" field="Isolation Kit (%)" desc=""/>
    <constraint exp="" field="Anode Potential (-mVCSE)" desc=""/>
    <constraint exp="" field="Anode Current (mA)" desc=""/>
    <constraint exp="" field="As Found Structure ON (-mVCSE)" desc=""/>
    <constraint exp="" field="As Found Structure OFF (-mVCSE)" desc=""/>
    <constraint exp="" field="Access" desc=""/>
    <constraint exp="" field="Deficiency ID" desc=""/>
    <constraint exp="" field="Reading Comments" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" type="field" name="Technician Name" hidden="0"/>
      <column width="-1" type="field" name="Date" hidden="0"/>
      <column width="-1" type="field" name="LSD" hidden="0"/>
      <column width="-1" type="field" name="SEC" hidden="0"/>
      <column width="-1" type="field" name="TWN" hidden="0"/>
      <column width="-1" type="field" name="RNG" hidden="0"/>
      <column width="-1" type="field" name="MER" hidden="0"/>
      <column width="-1" type="field" name="Location" hidden="0"/>
      <column width="-1" type="field" name="Location Description" hidden="0"/>
      <column width="-1" type="field" name="Secondary Description" hidden="0"/>
      <column width="-1" type="field" name="Structure Description" hidden="0"/>
      <column width="-1" type="field" name="License #" hidden="0"/>
      <column width="-1" type="field" name="Line #" hidden="0"/>
      <column width="-1" type="field" name="AER License #" hidden="0"/>
      <column width="-1" type="field" name="Latitude" hidden="0"/>
      <column width="-1" type="field" name="Longitude" hidden="0"/>
      <column width="-1" type="field" name="Pipe Size" hidden="0"/>
      <column width="-1" type="field" name="Material" hidden="0"/>
      <column width="-1" type="field" name="Substance" hidden="0"/>
      <column width="-1" type="field" name="Operational Status" hidden="0"/>
      <column width="-1" type="field" name="AC Potential (VAC)" hidden="0"/>
      <column width="-1" type="field" name="Static (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Structure Potential ON (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Structure Potential OFF (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Other Potential ON (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Other Potential OFF (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Swain Current Return(+)/Drain(-) (mA)" hidden="0"/>
      <column width="-1" type="field" name="Swain Current Return(+)/Drain(-) (mA) OFF" hidden="0"/>
      <column width="-1" type="field" name="Bond Current Return(+)/Drain(-) (mA)" hidden="0"/>
      <column width="-1" type="field" name="Bond Current Return(+)/Drain(-) (mA) OFF" hidden="0"/>
      <column width="-1" type="field" name="Isolation Kit (%)" hidden="0"/>
      <column width="-1" type="field" name="Anode Potential (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Anode Current (mA)" hidden="0"/>
      <column width="-1" type="field" name="As Found Structure ON (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="As Found Structure OFF (-mVCSE)" hidden="0"/>
      <column width="-1" type="field" name="Access" hidden="0"/>
      <column width="-1" type="field" name="Deficiency ID" hidden="0"/>
      <column width="-1" type="field" name="Reading Comments" hidden="0"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="AC Potential (VAC)"/>
    <field editable="1" name="AER License #"/>
    <field editable="1" name="Access"/>
    <field editable="1" name="Anode Current (mA)"/>
    <field editable="1" name="Anode Potential (-mVCSE)"/>
    <field editable="1" name="As Found Structure OFF (-mVCSE)"/>
    <field editable="1" name="As Found Structure ON (-mVCSE)"/>
    <field editable="1" name="Bond Current Return(+)/Drain(-) (mA)"/>
    <field editable="1" name="Bond Current Return(+)/Drain(-) (mA) OFF"/>
    <field editable="1" name="Date"/>
    <field editable="1" name="Deficiency ID"/>
    <field editable="1" name="Isolation Kit (%)"/>
    <field editable="1" name="LSD"/>
    <field editable="1" name="Latitude"/>
    <field editable="1" name="License #"/>
    <field editable="1" name="Line #"/>
    <field editable="1" name="Location"/>
    <field editable="1" name="Location Description"/>
    <field editable="1" name="Longitude"/>
    <field editable="1" name="MER"/>
    <field editable="1" name="Material"/>
    <field editable="1" name="Operational Status"/>
    <field editable="1" name="Other Potential OFF (-mVCSE)"/>
    <field editable="1" name="Other Potential ON (-mVCSE)"/>
    <field editable="1" name="Pipe Size"/>
    <field editable="1" name="RNG"/>
    <field editable="1" name="Reading Comments"/>
    <field editable="1" name="SEC"/>
    <field editable="1" name="Secondary Description"/>
    <field editable="1" name="Static (-mVCSE)"/>
    <field editable="1" name="Structure Description"/>
    <field editable="1" name="Structure Potential OFF (-mVCSE)"/>
    <field editable="1" name="Structure Potential ON (-mVCSE)"/>
    <field editable="1" name="Substance"/>
    <field editable="1" name="Swain Current Return(+)/Drain(-) (mA)"/>
    <field editable="1" name="Swain Current Return(+)/Drain(-) (mA) OFF"/>
    <field editable="1" name="TWN"/>
    <field editable="1" name="Technician Name"/>
  </editable>
  <labelOnTop>
    <field name="AC Potential (VAC)" labelOnTop="0"/>
    <field name="AER License #" labelOnTop="0"/>
    <field name="Access" labelOnTop="0"/>
    <field name="Anode Current (mA)" labelOnTop="0"/>
    <field name="Anode Potential (-mVCSE)" labelOnTop="0"/>
    <field name="As Found Structure OFF (-mVCSE)" labelOnTop="0"/>
    <field name="As Found Structure ON (-mVCSE)" labelOnTop="0"/>
    <field name="Bond Current Return(+)/Drain(-) (mA)" labelOnTop="0"/>
    <field name="Bond Current Return(+)/Drain(-) (mA) OFF" labelOnTop="0"/>
    <field name="Date" labelOnTop="0"/>
    <field name="Deficiency ID" labelOnTop="0"/>
    <field name="Isolation Kit (%)" labelOnTop="0"/>
    <field name="LSD" labelOnTop="0"/>
    <field name="Latitude" labelOnTop="0"/>
    <field name="License #" labelOnTop="0"/>
    <field name="Line #" labelOnTop="0"/>
    <field name="Location" labelOnTop="0"/>
    <field name="Location Description" labelOnTop="0"/>
    <field name="Longitude" labelOnTop="0"/>
    <field name="MER" labelOnTop="0"/>
    <field name="Material" labelOnTop="0"/>
    <field name="Operational Status" labelOnTop="0"/>
    <field name="Other Potential OFF (-mVCSE)" labelOnTop="0"/>
    <field name="Other Potential ON (-mVCSE)" labelOnTop="0"/>
    <field name="Pipe Size" labelOnTop="0"/>
    <field name="RNG" labelOnTop="0"/>
    <field name="Reading Comments" labelOnTop="0"/>
    <field name="SEC" labelOnTop="0"/>
    <field name="Secondary Description" labelOnTop="0"/>
    <field name="Static (-mVCSE)" labelOnTop="0"/>
    <field name="Structure Description" labelOnTop="0"/>
    <field name="Structure Potential OFF (-mVCSE)" labelOnTop="0"/>
    <field name="Structure Potential ON (-mVCSE)" labelOnTop="0"/>
    <field name="Substance" labelOnTop="0"/>
    <field name="Swain Current Return(+)/Drain(-) (mA)" labelOnTop="0"/>
    <field name="Swain Current Return(+)/Drain(-) (mA) OFF" labelOnTop="0"/>
    <field name="TWN" labelOnTop="0"/>
    <field name="Technician Name" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="AC Potential (VAC)"/>
    <field reuseLastValue="0" name="AER License #"/>
    <field reuseLastValue="0" name="Access"/>
    <field reuseLastValue="0" name="Anode Current (mA)"/>
    <field reuseLastValue="0" name="Anode Potential (-mVCSE)"/>
    <field reuseLastValue="0" name="As Found Structure OFF (-mVCSE)"/>
    <field reuseLastValue="0" name="As Found Structure ON (-mVCSE)"/>
    <field reuseLastValue="0" name="Bond Current Return(+)/Drain(-) (mA)"/>
    <field reuseLastValue="0" name="Bond Current Return(+)/Drain(-) (mA) OFF"/>
    <field reuseLastValue="0" name="Date"/>
    <field reuseLastValue="0" name="Deficiency ID"/>
    <field reuseLastValue="0" name="Isolation Kit (%)"/>
    <field reuseLastValue="0" name="LSD"/>
    <field reuseLastValue="0" name="Latitude"/>
    <field reuseLastValue="0" name="License #"/>
    <field reuseLastValue="0" name="Line #"/>
    <field reuseLastValue="0" name="Location"/>
    <field reuseLastValue="0" name="Location Description"/>
    <field reuseLastValue="0" name="Longitude"/>
    <field reuseLastValue="0" name="MER"/>
    <field reuseLastValue="0" name="Material"/>
    <field reuseLastValue="0" name="Operational Status"/>
    <field reuseLastValue="0" name="Other Potential OFF (-mVCSE)"/>
    <field reuseLastValue="0" name="Other Potential ON (-mVCSE)"/>
    <field reuseLastValue="0" name="Pipe Size"/>
    <field reuseLastValue="0" name="RNG"/>
    <field reuseLastValue="0" name="Reading Comments"/>
    <field reuseLastValue="0" name="SEC"/>
    <field reuseLastValue="0" name="Secondary Description"/>
    <field reuseLastValue="0" name="Static (-mVCSE)"/>
    <field reuseLastValue="0" name="Structure Description"/>
    <field reuseLastValue="0" name="Structure Potential OFF (-mVCSE)"/>
    <field reuseLastValue="0" name="Structure Potential ON (-mVCSE)"/>
    <field reuseLastValue="0" name="Substance"/>
    <field reuseLastValue="0" name="Swain Current Return(+)/Drain(-) (mA)"/>
    <field reuseLastValue="0" name="Swain Current Return(+)/Drain(-) (mA) OFF"/>
    <field reuseLastValue="0" name="TWN"/>
    <field reuseLastValue="0" name="Technician Name"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"Technician Name"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
