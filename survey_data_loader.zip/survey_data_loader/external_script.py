import zipfile
import pandas as pd
import os
import shutil
import xml.etree.ElementTree as ET
from qgis.PyQt.QtWidgets import QFileDialog
import tempfile
from qgis.core import *

#script_dir = os.path.dirname(os.path.abspath(__file__))
script_dir = self.plugin_dir
headercsvlocation = script_dir+"/headers.csv"
headercsv = pd.read_csv(headercsvlocation)
style_path = script_dir+"/pinstyle.qml"

#Clean up Previous runsOnSubFrames# Name of the layer to target
target_layer_name = "SurveyDataInProgress"
# Find all layers matching the name
existing_layers = QgsProject.instance().mapLayersByName(target_layer_name)
# Loop through and remove them from the project registry
for layer in existing_layers:
    QgsProject.instance().removeMapLayer(layer.id())


# Returns a tuple: (file_path, selected_filter)
filename, _ = QFileDialog.getOpenFileName(None, "Select File", "", "All Files (*);;Shapefiles (*.shp)")
if filename:
    print(f"Selected: {filename}")
if filename:
    folderpath = os.path.dirname(filename)
    surveyxlsx = os.path.basename(filename)

with tempfile.TemporaryDirectory() as fileroot:
    #Extract CSVs from Survey xlsx
    headers = "res/headers.csv"
    df = pd.read_excel(filename, sheet_name='Pipeline Potential Data', skiprows = 8, header =None, engine='openpyxl', engine_kwargs={'read_only': True})  # sheet_name is optional
    #Rough Headers Check
    if (df.iloc[0][37]=='Reading Comments'):
        df = df.drop([0,1,2], axis=0) #Drop header rows
        
        new_headers = headercsv.columns
        num_cols_to_replace = len(new_headers)
        
        # Replace only the first X column names in-place
        df.columns.values[:num_cols_to_replace] = new_headers
        df.to_csv(fileroot+"/surveydataextracted.csv", index=False)  # index=False prevents pandas from writing a row index to the CSV.
    else:
        print("Error! Input survey data format mismatch")

    #Survey Data File
    surveycsv = "surveydataextracted.csv"
    delimiterstring = ","
    x_field = "Longitude"
    y_field = "Latitude"
    survey_layer_name = "SurveyDataInProgress"
    crs = "EPSG:4326"
    
    #Import Survey Points
    uri = "file:///{}?delimiter={}&xField={}&yField={}&crs={}".format(fileroot+"/"+surveycsv, delimiterstring, x_field, y_field, crs)
    print(uri)
    temp_layer = QgsVectorLayer(uri, survey_layer_name, "delimitedtext")
    #vlayer.loadNamedStyle(fileroot+'/res/Survey_Style.qml')
    #vlayer.triggerRepaint()
    #QgsProject.instance().addMapLayer(vlayer)
    if temp_layer.isValid():
        # Duplicate features into memory
        mem_layer = temp_layer.materialize(QgsFeatureRequest())
        mem_layer.setName('SurveyDataInProgress')
        QgsProject.instance().addMapLayer(mem_layer)
        mem_layer.loadNamedStyle(style_path)
        mem_layer.triggerRepaint()
        del temp_layer

